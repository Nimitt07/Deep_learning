"""
Single-neuron Perceptron trained with the gradient-descent learning rule, implemented
from scratch (numpy is used only for array bookkeeping, not as an ML library).

Supported activation functions:
  - 'logistic' : f(net) = 1 / (1 + exp(-net))          -> targets in {0, 1}
  - 'tanh'     : f(net) = tanh(net)                     -> targets in {-1, 1}
  - 'linear'   : f(net) = net                           -> targets are real values (regression)

Weight update rule (online / per-sample gradient descent) minimizing E = 1/2 * (t - o)^2:
  delta = (t - o) * f'(net)
  w  <- w + eta * delta * x
  w0 <- w0 + eta * delta            (bias)
"""

import numpy as np


class Perceptron:
    def __init__(self, n_inputs, activation="logistic", learning_rate=0.01, seed=None):
        if activation not in ("logistic", "tanh", "linear"):
            raise ValueError(f"Unsupported activation: {activation}")
        rng = np.random.default_rng(seed)
        self.bias = float(rng.uniform(-0.5, 0.5))
        self.weights = rng.uniform(-0.5, 0.5, size=n_inputs)
        self.activation = activation
        self.lr = learning_rate

    def net_input(self, X):
        return X @ self.weights + self.bias

    def activate(self, net):
        if self.activation == "logistic":
            return 1.0 / (1.0 + np.exp(-net))
        if self.activation == "tanh":
            return np.tanh(net)
        return net  # linear

    def activate_derivative(self, out):
        if self.activation == "logistic":
            return out * (1.0 - out)
        if self.activation == "tanh":
            return 1.0 - out ** 2
        return np.ones_like(out)  # linear

    def predict_raw(self, X):
        return self.activate(self.net_input(X))

    def train(self, X, y, epochs=500, tol=1e-6, seed=None):
        """Online (per-sample) gradient descent. Returns list of average error per epoch."""
        rng = np.random.default_rng(seed)
        n_samples = X.shape[0]
        error_history = []
        for _epoch in range(epochs):
            order = rng.permutation(n_samples)
            sq_error_sum = 0.0
            for idx in order:
                xi = X[idx]
                ti = y[idx]
                net = self.net_input(xi)
                out = self.activate(net)
                err = ti - out
                delta = err * self.activate_derivative(out)
                self.weights += self.lr * delta * xi
                self.bias += self.lr * delta
                sq_error_sum += err ** 2
            avg_error = sq_error_sum / (2.0 * n_samples)
            error_history.append(avg_error)
            if avg_error < tol:
                break
        return error_history
